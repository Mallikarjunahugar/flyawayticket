package in.co.flyaway.ticket.bean;

public interface DropdownListBean {
	public String getKey();

	public String getValue();

}
